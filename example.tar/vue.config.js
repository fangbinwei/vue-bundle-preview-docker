module.exports = {
  publicPath: '/template'
}
